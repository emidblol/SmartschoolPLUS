const manifestUrl = browser.runtime.getManifest()
const storage = browser.storage
switch (storage.sync.get("theme")) {
    case "bavo":
        //change topnav class background color to darkgreen
        var topNav = document.getElementsByClassName("topnav");
        topNav[0].style.backgroundColor = "darkgreen";

        var gotomenu = document.getElementById("shortcutsMenu").children[0];
        //Add a new menu item to the topnav
        /*example of a button:
        <a href="/index.php?module=Messages&amp;file=index&amp;function=main" class="topnav__menuitem topnav__menuitem--icon module-messages--24" role="menuitem" title="Berichten" column-index="0" item-index="0">
                Berichten
            </a>
        */
        var newMenuItem = document.createElement("a");
        newMenuItem.setAttribute("href", manifestUrl.homepage_url);
        //get the manifest ID
        console.log(browser.runtime.getManifest())
        newMenuItem.style.backgroundImage = "url('" + manifestUrl.icons["48"] + "')";
        newMenuItem.setAttribute("class", "topnav__menuitem topnav__menuitem--icon");
        newMenuItem.setAttribute("role", "menuitem");
        newMenuItem.setAttribute("title", "Smartschool Plus");
        newMenuItem.setAttribute("column-index", "0");
        newMenuItem.setAttribute("item-index", "0");
        newMenuItem.innerHTML = "Smartschool Plus";
        gotomenu.appendChild(newMenuItem);

        var startbutton = document.getElementsByClassName("topnav__btn--push-right")[0];
        const startbuttonicon = document.createElement("img")
        startbuttonicon.setAttribute("src", manifestUrl.icons["96"])
        //on hover of the startbutton, invert the image using css
        document.styleSheets[0].insertRule(".invert {filter: invert(90%);}", 0);
        //add the class, don't set it
        startbuttonicon.className += "invert";
        startbutton.innerHTML = "";
        startbutton.appendChild(startbuttonicon);
        break;
    case undefined:
        storage.sync.theme = "bavo";
}